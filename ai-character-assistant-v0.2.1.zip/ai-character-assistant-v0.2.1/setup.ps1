﻿param([switch]$SkipSpeech)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
New-Item -ItemType Directory -Path '.runtime' -Force | Out-Null
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js 22 이상을 먼저 설치하고 터미널을 다시 열어주세요.' }
& node -e 'if (parseInt(process.versions.node) < 22) process.exit(1)'
if ($LASTEXITCODE -ne 0) { throw 'Node.js 22 이상이 필요합니다.' }
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) { throw 'pnpm 11 이상을 먼저 설치하세요: npm install --global pnpm@11' }
& pnpm install --frozen-lockfile --ignore-scripts --node-linker=hoisted
if ($LASTEXITCODE -ne 0) { throw '서버 의존성 설치 실패' }
Push-Location -LiteralPath 'frontend'
try {
    & pnpm install --frozen-lockfile --ignore-scripts --node-linker=hoisted
    if ($LASTEXITCODE -ne 0) { throw '화면 의존성 설치 실패' }
    $env:ELECTRON_CACHE = Join-Path $PSScriptRoot '.runtime\electron-cache'
    & node node_modules/electron/install.js
    if ($LASTEXITCODE -ne 0) { throw 'Electron 다운로드 실패' }
    & pnpm run build
    if ($LASTEXITCODE -ne 0) { throw '데스크톱 빌드 실패' }
    & pnpm run build:web
    if ($LASTEXITCODE -ne 0) { throw '웹 화면 빌드 실패' }
} finally { Pop-Location }
if (-not $SkipSpeech) { & (Join-Path $PSScriptRoot 'setup-speech.ps1') }
Write-Output '설치 완료. start.ps1 실행 후 http://127.0.0.1:12393 에서 본인 계정으로 로그인하세요.'
