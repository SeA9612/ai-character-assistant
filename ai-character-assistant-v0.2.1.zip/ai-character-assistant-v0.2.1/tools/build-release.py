"""Build a source release from an explicit allowlist, never the live runtime."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = json.loads((ROOT / 'package.json').read_text(encoding='utf-8'))['version']
NAME = f"ai-character-assistant-v{VERSION}"
STAGE = ROOT / ".release" / NAME
OUT = ROOT / "releases"
files = {}


def add(relative):
    source = ROOT / relative
    if not source.is_file() or source.is_symlink():
        raise RuntimeError(f"Expected regular source file: {relative}")
    files[relative] = source.read_bytes()


def tree(relative):
    for source in sorted((ROOT / relative).rglob("*")):
        if not source.is_file():
            continue
        path = source.relative_to(ROOT)
        if any(part in {"__pycache__", "node_modules", ".git", ".runtime"} for part in path.parts):
            continue
        if source.suffix in {".pyc", ".map"}:
            continue
        if path.as_posix().endswith("public/libs/live2d.min.js"):
            continue  # Unused legacy runtime; current UI uses Cubism Core.
        add(path.as_posix())


for relative in [
    "package.json", "pnpm-lock.yaml", ".gitignore", "setup.ps1", "setup-speech.ps1",
    "speech-requirements.txt", "start.ps1", "start.cmd", "start-desktop.ps1",
    "upstream-manifest.json", "local-changes.json", "backend/pyproject.toml",
    "frontend/package.json", "frontend/package-lock.json", "frontend/pnpm-lock.yaml",
    "frontend/electron.vite.config.ts", "frontend/vite.config.ts", "frontend/electron-builder.yml",
    "frontend/tsconfig.json", "frontend/tsconfig.app.json", "frontend/tsconfig.node.json",
    "frontend/tsconfig.web.json", "frontend/.eslintrc.js", "frontend/.eslintignore",
    "frontend/i18next-scanner.config.js", "frontend/LICENSE",
    "tools/verify_extraction.py", "tools/record-local-changes.py", "tools/check-account.mjs",
    "tools/build-release.py",
    "docs/PC_ASSISTANT.md",
    "docs/PET_MODE_FIX.md",
]:
    add(relative)

for relative in ["server", "tests", "backend/src", "frontend/src", "frontend/resources", "assets", "licenses", "docs/release"]:
    tree(relative)

for name in ["README.md", "RELEASE_NOTES.md", "PRIVACY.md", "LICENSE.md", "실행방법.txt"]:
    files[name] = (ROOT / "docs/release" / name).read_bytes()

# Preserve provenance for shipped upstream files, with no claim about excluded maps.
manifest = json.loads(files["upstream-manifest.json"])
omitted = [item for item in manifest["files"] if item["path"] not in files]
manifest["files"] = [item for item in manifest["files"] if item["path"] in files]
manifest["excluded_files"] = [{"path": item["path"], "reason": "Unused legacy runtime or non-redistributable debug map omitted from release"} for item in omitted]
files["upstream-manifest.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()

for name, data in list(files.items()):
    if name.endswith(".ps1") or name in {"실행방법.txt", "docs/release/실행방법.txt", "speech-requirements.txt"}:
        # Windows PowerShell 5 and Notepad both recognize UTF-8 BOM reliably.
        text = data.decode("utf-8-sig").replace("\r\n", "\n")
        files[name] = ("\ufeff" + text.replace("\n", "\r\n")).encode("utf-8")

username = Path.home().name.encode()
patterns = [
    rb"gh[pousr]_[A-Za-z0-9]{20,}", rb"github_pat_[A-Za-z0-9_]{20,}",
    rb"sk-(?:proj-)?[A-Za-z0-9_-]{24,}",
    rb"eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}",
    rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
    rb"[A-Z]:[\\/]+Users[\\/]+[^\s\"']+",
    rb"[A-Z0-9._%+-]+@(?:gmail|hotmail|outlook|icloud|protonmail)\.[A-Z]{2,}",
]
issues = []
for name, data in files.items():
    parts = Path(name).parts
    if any(part in {".runtime", ".upstream", "node_modules", "test-results", ".git"} for part in parts):
        issues.append(f"Private path: {name}")
    if Path(name).name.lower() in {"auth.json", ".env", ".npmrc"} or name.endswith((".log", ".sqlite", ".db", ".pid", ".pem", ".pfx", ".key")):
        issues.append(f"Private file type: {name}")
    if username.lower() in data.lower() or username.decode().encode("utf-16-le").lower() in data.lower():
        issues.append(f"Local username found: {name}")
    for pattern in patterns:
        if re.search(pattern, data, re.I):
            issues.append(f"Potential private value: {name}")
            break
if issues:
    raise RuntimeError("Release blocked:\n" + "\n".join(issues))

files["PRIVACY_CHECK.json"] = (json.dumps({
    "release": VERSION, "checkedFiles": len(files), "result": "passed",
    "credentialsIncluded": False, "developerAccountIncluded": False,
    "conversationHistoryIncluded": False, "screenshotsOrRecordingsIncluded": False,
    "runtimeOrDependencyCachesIncluded": False,
    "checks": ["allowlisted files only", "private file paths", "local username and absolute user paths", "consumer email addresses", "common token and private-key patterns"],
    "note": "Automated packaging checks, not a guarantee about all possible sensitive data. Third-party copyright notices preserved.",
}, ensure_ascii=False, indent=2) + "\n").encode()
files["PACKAGE_MANIFEST.json"] = (json.dumps({name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())}, indent=2) + "\n").encode()

STAGE.mkdir(parents=True, exist_ok=True)
for name, data in files.items():
    destination = STAGE / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)

OUT.mkdir(exist_ok=True)
archive = OUT / f"{NAME}.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as package:
    for name, data in sorted(files.items()):
        package.writestr(f"{NAME}/{name}", data)
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(OUT / "SHA256SUMS.txt").write_text(f"{digest}  {archive.name}\n", encoding="utf-8")
for name in ["README.md", "RELEASE_NOTES.md", "실행방법.txt", "PRIVACY_CHECK.json", "PRIVACY.md", "LICENSE.md"]:
    (OUT / name).write_bytes(files[name])
(OUT / "RUN_GUIDE_KO.txt").write_bytes(files['실행방법.txt'])
print(json.dumps({"files": len(files), "archive": str(archive), "bytes": archive.stat().st_size, "sha256": digest}, ensure_ascii=False))
