"""Record deliberate changes to vendored files without altering original hashes."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "upstream-manifest.json").read_text(encoding="utf-8"))
changes = []
for item in manifest["files"]:
    current = hashlib.sha256((root / item["path"]).read_bytes()).hexdigest()
    if current != item["sha256"]:
        changes.append({"path": item["path"], "original_sha256": item["sha256"], "sha256": current})
(root / "local-changes.json").write_text(json.dumps(changes, indent=2) + "\n", encoding="utf-8")
print(f"Recorded {len(changes)} deliberately modified upstream files")
