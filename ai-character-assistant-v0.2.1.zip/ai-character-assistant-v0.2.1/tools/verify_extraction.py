"""Offline structural verification; no model, microphone, or API calls."""
from pathlib import Path
import ast
import hashlib
import json
import re
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]
errors = []
manifest = json.loads((ROOT / "upstream-manifest.json").read_text(encoding="utf-8"))
change_path = ROOT / "local-changes.json"
changes = {item["path"]: item for item in json.loads(change_path.read_text(encoding="utf-8"))} if change_path.exists() else {}
for entry in manifest["files"]:
    path = ROOT / entry["path"]
    change = changes.get(entry["path"])
    expected = change["sha256"] if change else entry["sha256"]
    if change and change["original_sha256"] != entry["sha256"]:
        errors.append(f"Original provenance mismatch: {entry['path']}")
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        errors.append(f"Missing or modified upstream file: {entry['path']}")

python_files = list((ROOT / "backend/src").rglob("*.py"))
for path in python_files:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for item in ast.walk(tree):
        if isinstance(item, ast.ImportFrom) and item.level:
            base = path.parent
            for _ in range(item.level - 1):
                base = base.parent
            target = base.joinpath(*(item.module or "").split("."))
            if not target.with_suffix(".py").exists() and not (target / "__init__.py").exists():
                errors.append(f"Missing Python import: {path.name}: {item.module}")

tomllib.loads((ROOT / "backend/pyproject.toml").read_text(encoding="utf-8"))
for path in [ROOT / "frontend/package.json", ROOT / "frontend/package-lock.json"]:
    json.loads(path.read_text(encoding="utf-8"))

src = ROOT / "frontend/src"
aliases = {
    "@/": src / "renderer/src",
    "@framework/": src / "renderer/WebSDK/Framework/src",
    "@cubismsdksamples/": src / "renderer/WebSDK/src",
}
imports = 0
for path in src.rglob("*"):
    if path.suffix not in {".ts", ".tsx", ".js", ".jsx"}:
        continue
    text = path.read_text(encoding="utf-8-sig")
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"^\s*//.*$", "", text, flags=re.M)
    for match in re.finditer(r'''(?:\bfrom\s*|\bimport\s*)["']([^"']+)["']''', text):
        spec = match.group(1).split("?")[0]
        target = None
        if spec.startswith("."):
            target = path.parent / spec
        else:
            for prefix, base in aliases.items():
                if spec.startswith(prefix):
                    target = base / spec[len(prefix):]
                    break
        if target is None:
            continue
        imports += 1
        candidates = [target] + [Path(str(target) + suffix) for suffix in [".ts", ".tsx", ".js", ".jsx", ".json", ".d.ts"]]
        candidates += [target / ("index" + suffix) for suffix in [".ts", ".tsx", ".js", ".jsx"]]
        if not any(candidate.is_file() for candidate in candidates):
            errors.append(f"Missing frontend import: {path.relative_to(ROOT)}: {spec}")

model = ROOT / "assets/live2d-models/mao_pro/runtime/mao_pro.model3.json"
refs = json.loads(model.read_text(encoding="utf-8"))["FileReferences"]

def check_assets(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {"Moc", "Textures", "Physics", "Pose", "UserData", "DisplayInfo", "File", "Sound"}:
                for name in child if isinstance(child, list) else [child]:
                    if name and isinstance(name, str) and not (model.parent / name).is_file():
                        errors.append(f"Missing model asset: {name}")
            else:
                check_assets(child)
    elif isinstance(value, list):
        for child in value:
            check_assets(child)

check_assets(refs)
for name in ["licenses/Open-LLM-VTuber.LICENSE", "licenses/Open-LLM-VTuber-Web.LICENSE", "licenses/LICENSE-Live2D.md", "frontend/src/renderer/WebSDK/Core/LICENSE.md", "frontend/src/renderer/WebSDK/Framework/LICENSE.md"]:
    if not (ROOT / name).is_file():
        errors.append(f"Missing license: {name}")

if errors:
    print("\n".join(errors))
    sys.exit(1)
print(f"PASS: {len(manifest['files'])} source hashes, {len(python_files)} Python modules, {imports} frontend imports, model assets, JSON/TOML and licenses")
