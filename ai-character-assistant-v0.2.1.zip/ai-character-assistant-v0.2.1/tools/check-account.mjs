import { CodexBridge } from '../server/codex.mjs';
import { ROOT } from '../server/main.mjs';
const bridge = new CodexBridge({ root: ROOT });
try {
  const status = await bridge.status();
  console.log(JSON.stringify(status));
  if (process.argv.includes('--live')) {
    const reply = await bridge.generate({ messages: [{ role: 'human', content: '연결 테스트입니다. 다른 설명 없이 한국어로 연결 성공이라고만 답해주세요.' }] });
    console.log(JSON.stringify({ liveReply: reply }));
  }
} catch(error) { console.error(error.message); process.exitCode = 1; }
finally { bridge.close(); }
