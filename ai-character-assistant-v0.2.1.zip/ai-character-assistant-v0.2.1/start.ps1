﻿param([switch]$Mock)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
$nodePath = if ($nodeCommand) { $nodeCommand.Source } else { Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' }
if (-not (Test-Path -LiteralPath $nodePath)) { throw 'Node.js 22 이상을 설치해주세요.' }
if (-not (Get-Command codex -ErrorAction SilentlyContinue) -and -not $env:CODEX_BINARY) {
    $codexRoot = Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\bin'
    if (Test-Path -LiteralPath $codexRoot) {
        $codexCandidate = Get-ChildItem -LiteralPath $codexRoot -Filter codex.exe -Recurse -File | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($codexCandidate) { $env:CODEX_BINARY = $codexCandidate.FullName }
    }
}
if (-not (Test-Path -LiteralPath 'node_modules/ws')) {
    throw '먼저 프로젝트 의존성을 설치해주세요. README.md를 확인하세요.'
}
if ($Mock) { & $nodePath 'server/main.mjs' '--mock' }
else { & $nodePath 'server/main.mjs' }
