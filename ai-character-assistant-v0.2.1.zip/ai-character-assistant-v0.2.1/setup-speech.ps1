﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$env:UV_PYTHON_INSTALL_DIR = Join-Path $PSScriptRoot '.runtime\python'
$env:UV_CACHE_DIR = Join-Path $PSScriptRoot '.runtime\uv-cache'
$uvPath = Join-Path $PSScriptRoot '.runtime\uv-tool\bin\uv.exe'
if (-not (Test-Path -LiteralPath $uvPath)) {
    & python -m pip install --target .runtime/uv-tool uv==0.13.7
    if ($LASTEXITCODE -ne 0) { throw 'uv 설치 실패' }
}
& $uvPath python install 3.12
if ($LASTEXITCODE -ne 0) { throw 'Python 설치 실패' }
& $uvPath venv --python 3.12 .runtime/speech-venv
if ($LASTEXITCODE -ne 0) { throw '음성 환경 생성 실패' }
& $uvPath pip install --python .runtime/speech-venv/Scripts/python.exe -r speech-requirements.txt
if ($LASTEXITCODE -ne 0) { throw '음성 패키지 설치 실패' }
