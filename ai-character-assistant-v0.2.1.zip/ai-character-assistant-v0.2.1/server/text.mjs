// The character UI and TTS consume plain text rather than Markdown.
export function cleanReply(text) {
  return text
    .replace(/\[(?:joy|neutral|anger|disgust|fear|smirk|sadness|surprise)\]/gi, '')
    .replace(/\*\*([\s\S]+?)\*\*/g, '$1')
    .replace(/__([^\n]+?)__/g, '$1')
    .replace(/`([^`\n]+)`/g, '$1')
    .trim();
}
