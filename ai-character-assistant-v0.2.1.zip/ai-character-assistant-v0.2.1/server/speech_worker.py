"""Local ASR + Edge TTS, JSON-lines over stdio. No microphone access here."""
import asyncio
import base64
import io
import json
import os
from pathlib import Path
import sys
import wave

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("HF_HOME", str(ROOT / ".runtime/models/huggingface"))
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
model = None


def transcribe(request):
    global model
    import numpy as np
    from faster_whisper import WhisperModel
    audio = np.frombuffer(base64.b64decode(request["audio"], validate=True), dtype="<f4")
    if len(audio) > 16000 * 60 or not np.isfinite(audio).all():
        raise ValueError("음성은 최대 60초이며 유한한 샘플이어야 합니다.")
    if len(audio) < 1600 or np.max(np.abs(audio)) < 0.001:
        return {"text": ""}
    if model is None:
        model = WhisperModel(os.environ.get("ASSISTANT_ASR_MODEL", "base"), device="cpu", compute_type="int8",
                             download_root=str(ROOT / ".runtime/models/whisper"), cpu_threads=4)
    segments, info = model.transcribe(audio, language="ko", beam_size=5, condition_on_previous_text=False,
                                      vad_filter=True, initial_prompt="한국어로 AI 비서와 대화합니다.")
    return {"text": "".join(segment.text for segment in segments).strip(), "language": info.language}


async def synthesize(request):
    import edge_tts
    import av
    text = request.get("text", "").strip()
    if not text or len(text) > 4000:
        raise ValueError("합성할 텍스트는 1~4,000자여야 합니다.")
    audio = bytearray()
    communicate = edge_tts.Communicate(text, os.environ.get("ASSISTANT_TTS_VOICE", "ko-KR-SunHiNeural"))
    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            audio.extend(chunk["data"])
    if not audio:
        raise RuntimeError("음성 합성 서비스가 오디오를 반환하지 않았습니다.")
    source = av.open(io.BytesIO(audio))
    resampler = av.AudioResampler(format="s16", layout="mono", rate=24000)
    pcm = bytearray()
    for frame in source.decode(audio=0):
        for converted in resampler.resample(frame):
            pcm.extend(converted.to_ndarray().tobytes())
    for converted in resampler.resample(None):
        pcm.extend(converted.to_ndarray().tobytes())
    source.close()
    output = io.BytesIO()
    with wave.open(output, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(24000)
        wav.writeframes(pcm)
    return {"audio": base64.b64encode(output.getvalue()).decode("ascii"), "mime": "audio/wav", "seconds": len(pcm) / 48000}


def main():
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8")
    for line in sys.stdin:
        request = {}
        try:
            request = json.loads(line)
            if request["method"] == "tts":
                result = asyncio.run(synthesize(request))
            elif request["method"] == "asr":
                result = transcribe(request)
            else:
                raise ValueError("지원하지 않는 음성 요청")
            response = {"id": request["id"], "result": result}
        except Exception as exc:
            response = {"id": request.get("id"), "error": f"{type(exc).__name__}: {exc}"}
        print(json.dumps(response, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
