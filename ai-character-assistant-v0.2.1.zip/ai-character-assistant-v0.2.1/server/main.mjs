import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { WebSocketServer } from 'ws';
import { CodexBridge, MockBridge } from './codex.mjs';
import { HistoryStore } from './history.mjs';
import { SpeechBridge } from './speech.mjs';
import { cleanReply as cleanText } from './text.mjs';
import { PcTools } from './pc.mjs';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.wasm': 'application/wasm', '.moc3': 'application/octet-stream' };
const expressions = { neutral: 0, anger: 2, disgust: 2, fear: 1, joy: 3, smirk: 3, sadness: 1, surprise: 3 };

export function createAssistant({ root = ROOT, bridge = new CodexBridge({ root }), speech = null, pc = new PcTools({ root }), port = 12393, historyDirectory = path.join(root, '.runtime', 'history') } = {}) {
  const histories = new HistoryStore(historyDirectory);
  const peers = new Set();
  function allowed(req) {
    const host = req.headers.host || '';
    if (!/^(127\.0\.0\.1|localhost):\d+$/.test(host)) return false;
    const origin = req.headers.origin;
    return !origin || (['null', 'file://'].includes(origin) && /Electron\//.test(req.headers['user-agent'] || '')) || origin === `http://${host}` || origin === 'http://localhost:3000' || origin === 'http://127.0.0.1:3000';
  }
  const server = http.createServer(async (req, res) => {
    if (!allowed(req)) { res.writeHead(403).end('Forbidden'); return; }
    if (req.headers.origin && req.headers.origin !== 'null') {
      res.setHeader('Access-Control-Allow-Origin', req.headers.origin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    }
    res.setHeader('X-Content-Type-Options', 'nosniff');
    const json = (status, value) => { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(value)); };
    try {
      const url = new URL(req.url, 'http://127.0.0.1');
      if (req.method === 'OPTIONS') { res.writeHead(204).end(); return; }
      if (url.pathname === '/health') { json(200, { ok: true, mode: bridge instanceof MockBridge ? 'mock' : 'codex' }); return; }
      if (req.method === 'GET' && url.pathname === '/api/status') { json(200, await bridge.status()); return; }
      if (req.method === 'GET' && url.pathname === '/api/models') { json(200, { models: await bridge.models() }); return; }
      if (req.method === 'POST' && url.pathname === '/api/login') { json(200, await bridge.login()); return; }
      if (req.method !== 'GET') { json(405, { error: '지원하지 않는 요청입니다.' }); return; }
      let base, relative;
      if (url.pathname === '/') { base = path.join(root, 'server/public'); relative = 'index.html'; }
      else if (url.pathname === '/bg/default.svg') { base = path.join(root, 'server/public'); relative = 'bg/default.svg'; }
      else if (url.pathname === '/test-screen/') { base = path.join(root, 'server/public'); relative = 'test-screen.html'; }
      else if (url.pathname === '/app' || url.pathname.startsWith('/app/')) { base = path.join(root, 'frontend/dist/web'); relative = decodeURIComponent(url.pathname.slice(5)) || 'index.html'; }
      else if (url.pathname.startsWith('/live2d-models/') || url.pathname.startsWith('/avatars/')) { base = path.join(root, 'assets'); relative = decodeURIComponent(url.pathname.slice(1)); }
      else { json(404, { error: '찾을 수 없습니다.' }); return; }
      const target = path.resolve(base, relative);
      if (!target.startsWith(base + path.sep) || !(await stat(target)).isFile()) { json(404, { error: '찾을 수 없습니다.' }); return; }
      res.writeHead(200, { 'Content-Type': mime[path.extname(target)] || 'application/octet-stream' });
      res.end(await readFile(target));
    } catch (error) { json(error.code === 'ENOENT' ? 404 : 503, { error: error.code === 'ENOENT' ? '화면 빌드 파일이 없습니다. frontend 빌드를 실행하세요.' : error.message }); }
  });
  const wss = new WebSocketServer({ noServer: true, maxPayload: 8 * 1024 * 1024 });
  server.on('upgrade', (req, socket, head) => {
    if (!allowed(req) || req.url !== '/client-ws') { socket.end('HTTP/1.1 403 Forbidden\r\n\r\n'); return; }
    wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws));
  });
  wss.on('connection', ws => {
    peers.add(ws);
    let current, active, chain = Promise.resolve(), audioChunks = [], audioLength = 0, lastProactiveAt = 0, speechEnabled = true, pcEnabled = true;
    const approvals = new Map();
    const send = value => { if (ws.readyState === 1) ws.send(JSON.stringify(value)); };
    const approve = (details, signal) => new Promise(resolve => {
      if (signal?.aborted || ws.readyState !== 1) { resolve(false); return; }
      const id = randomUUID();
      const finish = answer => { clearTimeout(timer); signal?.removeEventListener('abort', cancel); approvals.delete(id); send({ type: 'pc-approval-closed', id }); resolve(answer); };
      const cancel = () => finish(false);
      const timer = setTimeout(cancel, 120000);
      approvals.set(id, finish);
      signal?.addEventListener('abort', cancel, { once: true });
      send({ type: 'pc-approval', id, ...details });
    });
    const end = () => { send({ type: 'backend-synth-complete' }); send({ type: 'control', text: 'conversation-chain-end' }); };
    const start = async () => {
      const [model] = JSON.parse(await readFile(path.join(root, 'assets/model_dict.json'), 'utf8'));
      send({ type: 'set-model-and-conf', model_info: model, conf_name: 'AI 캐릭터 비서', conf_uid: 'assistant', client_uid: randomUUID() });
      send({ type: 'full-text', text: bridge instanceof MockBridge ? '로컬 테스트 모드 · 실제 AI에 연결하지 않습니다.' : '안녕하세요! 무엇을 도와드릴까요?' });
    };
    chain = start();
    async function converse(message, existingController) {
      if (message.type === 'ai-speak-signal') {
        const manual = message.idle_time === -1;
        if (!manual && (!Number.isFinite(message.idle_time) || message.idle_time < 5)) throw new Error('먼저 말하기 대기 시간은 5초 이상이어야 합니다.');
        if (!manual && Date.now() - lastProactiveAt < 15000) return;
        if (!manual) lastProactiveAt = Date.now();
      }
      const text = message.type === 'ai-speak-signal' ? '상황에 맞게 짧게 먼저 말을 걸어주세요.' : message.text;
      if (typeof text !== 'string' || !text.trim() || text.length > 20000) throw new Error('1~20,000자의 메시지를 입력하세요.');
      const images = message.images || [];
      if (!Array.isArray(images) || images.length > 4 || images.some(i => typeof i?.data !== 'string' || !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(i.data))) throw new Error('지원하지 않는 이미지 입력입니다.');
      if (!current) current = await histories.create();
      const controller = existingController || new AbortController();
      active = controller;
      const proactive = message.type === 'ai-speak-signal';
      let toolsDenied = false;
      if (!proactive) {
        current.messages.push({ role: 'human', content: text, timestamp: new Date().toISOString() });
        await histories.save(current);
      }
      const context = proactive ? [...current.messages, { role: 'human', content: text }] : current.messages;
      send({ type: 'control', text: 'conversation-chain-start' });
      try {
        const reply = await bridge.generate({ messages: context.slice(-30), images, signal: controller.signal,
          onTool: !proactive && pcEnabled ? async args => {
            if (!pcEnabled || toolsDenied || controller.signal.aborted) throw new Error('PC 작업이 중지되었거나 승인이 거절되었습니다.');
            const id = randomUUID();
            const progress = status => send({ type: 'tool_call_status', tool_id: id, tool_name: args.action, name: '비서', status, content: args.reason, timestamp: new Date().toISOString() });
            progress('running');
            try {
              const result = await pc.execute(args, { signal: controller.signal, approve: async (details, signal) => {
                const accepted = await approve(details, signal);
                if (!accepted) toolsDenied = true;
                return accepted;
              } });
              progress('completed'); return result;
            } catch (error) { progress('error'); throw error; }
          } : null,
          onDelta: partial => { if (!controller.signal.aborted) send({ type: 'full-text', text: cleanText(partial) }); } });
        if (controller.signal.aborted) return;
        const content = cleanText(reply);
        current.messages.push({ role: 'ai', content, timestamp: new Date().toISOString() });
        current.timestamp = new Date().toISOString();
        await histories.save(current);
        const emotion = reply.match(/\[(\w+)\]/)?.[1]?.toLowerCase() || 'neutral';
        let audio;
        if (speech && speechEnabled) {
          try { audio = (await speech.synthesize(content.slice(0, 4000), { signal: controller.signal })).audio; }
          catch (error) { if (!controller.signal.aborted) send({ type: 'error', message: '음성 생성 실패 (텍스트 응답은 유지): ' + error.message }); }
        }
        if (controller.signal.aborted) return;
        send({ type: 'audio', audio, display_text: { text: content, name: '비서', avatar: '/avatars/mao.png' }, actions: { expressions: [expressions[emotion] ?? 0] } });
        send({ type: 'full-text', text: content });
      } catch (error) { if (!controller.signal.aborted) send({ type: 'error', message: error.message }); }
      finally { if (active === controller) active = null; end(); }
    }
    async function handle(m) {
      switch (m.type) {
        case 'fetch-backgrounds': send({ type: 'background-files', files: [] }); break;
        case 'fetch-configs': send({ type: 'config-files', configs: [{ filename: 'assistant', name: 'AI 캐릭터 비서' }] }); break;
        case 'fetch-history-list': send({ type: 'history-list', histories: await histories.list() }); break;
        case 'create-new-history': current = await histories.create(); send({ type: 'new-history-created', history_uid: current.uid }); break;
        case 'fetch-and-set-history': current = await histories.read(m.history_uid); send({ type: 'history-data', messages: current.messages.map(item => item.role === 'ai' ? { ...item, content: cleanText(item.content) } : item) }); break;
        case 'delete-history': send({ type: 'history-deleted', success: false }); send({ type: 'error', message: '현재 버전에서는 대화 삭제를 지원하지 않습니다.' }); break;
        case 'text-input': case 'ai-speak-signal': await converse(m); break;
        case 'set-speech': speechEnabled = m.enabled === true; break;
        case 'mic-audio-data':
          if (!Array.isArray(m.audio) || m.audio.length > 16384 || m.audio.some(v => typeof v !== 'number' || !Number.isFinite(v) || Math.abs(v) > 1.01)) { audioChunks = []; audioLength = 0; throw new Error('잘못된 음성 샘플입니다.'); }
          audioLength += m.audio.length;
          if (audioLength > 16000 * 60) { audioChunks = []; audioLength = 0; throw new Error('음성은 최대 60초까지 입력할 수 있습니다.'); }
          audioChunks.push(m.audio); break;
        case 'mic-audio-end': {
          const chunks = audioChunks; audioChunks = []; audioLength = 0;
          if (!speech) { send({ type: 'error', message: '음성 엔진이 비활성화되어 있습니다.' }); end(); break; }
          const controller = new AbortController(); active = controller;
          send({ type: 'control', text: 'conversation-chain-start' });
          try {
            const { text } = await speech.transcribe(chunks, { signal: controller.signal });
            if (controller.signal.aborted) break;
            if (!text.trim()) { send({ type: 'full-text', text: '음성이 잘 들리지 않았어요. 다시 말씀해주세요.' }); end(); break; }
            send({ type: 'user-input-transcription', text });
            await converse({ type: 'text-input', text, images: m.images }, controller);
          } catch (error) { if (!controller.signal.aborted) send({ type: 'error', message: error.message }); end(); }
          finally { if (active === controller) active = null; }
          break;
        }
        case 'frontend-playback-complete': case 'audio-play-start': break;
        case 'interrupt-signal': break;
        default: send({ type: 'error', message: `아직 지원하지 않는 기능: ${String(m.type).slice(0, 60)}` });
      }
    }
    ws.on('message', raw => {
      let message;
      try { message = JSON.parse(raw); if (!message || typeof message.type !== 'string') throw new Error(); }
      catch { send({ type: 'error', message: '잘못된 메시지입니다.' }); return; }
      if (message.type === 'interrupt-signal') { audioChunks = []; audioLength = 0; active?.abort(); return; }
      // Approval replies must bypass the queue: the current turn is waiting for them.
      if (message.type === 'pc-approval-response') { approvals.get(message.id)?.(message.approved === true); return; }
      if (message.type === 'set-pc-enabled') { const previous = pcEnabled; pcEnabled = message.enabled === true; if (previous && !pcEnabled) active?.abort(); send({ type: 'pc-state', enabled: pcEnabled }); return; }
      if (message.type === 'set-speech') { speechEnabled = message.enabled === true; return; }
      // Preserve message order, but allow interruption to bypass the queue.
      chain = chain.then(() => ws.readyState === 1 && handle(message)).catch(error => { send({ type: 'error', message: error.message }); end(); });
    });
    ws.on('close', () => { active?.abort(); for (const done of [...approvals.values()]) done(false); peers.delete(ws); });
  });
  return {
    server, bridge, histories,
    async listen() { await new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, '127.0.0.1', resolve); }); return server.address().port; },
    async close() { for (const ws of peers) ws.terminate(); bridge.close(); speech?.close(); await new Promise(resolve => wss.close(resolve)); await new Promise(resolve => server.close(resolve)); },
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const app = createAssistant({ bridge: process.argv.includes('--mock') ? new MockBridge() : new CodexBridge({ root: ROOT }), speech: process.argv.includes('--mock') || process.argv.includes('--no-speech') ? null : new SpeechBridge({ root: ROOT }), port: Number(process.env.ASSISTANT_PORT || 12393) });
  const port = await app.listen();
  console.log(`AI 캐릭터 비서: http://127.0.0.1:${port} (${process.argv.includes('--mock') ? '로컬 테스트' : 'ChatGPT 구독'})`);
  for (const event of ['SIGINT', 'SIGTERM']) process.once(event, async () => { await app.close(); process.exit(0); });
}
