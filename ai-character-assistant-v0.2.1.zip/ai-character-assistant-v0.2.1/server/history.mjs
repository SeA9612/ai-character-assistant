import { mkdir, readFile, writeFile, rename, readdir } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import path from 'node:path';

export class HistoryStore {
  constructor(directory) { this.directory = directory; }
  location(uid) {
    if (!/^[0-9a-f-]{36}$/.test(uid)) throw new Error('잘못된 대화 ID입니다.');
    return path.join(this.directory, uid + '.json');
  }
  async save(history) {
    await mkdir(this.directory, { recursive: true });
    const target = this.location(history.uid), temp = target + '.' + randomUUID() + '.tmp';
    await writeFile(temp, JSON.stringify(history, null, 2), 'utf8');
    await rename(temp, target);
  }
  async create() {
    const history = { uid: randomUUID(), timestamp: new Date().toISOString(), messages: [] };
    await this.save(history);
    return history;
  }
  async read(uid) { return JSON.parse(await readFile(this.location(uid), 'utf8')); }
  async list() {
    await mkdir(this.directory, { recursive: true });
    const files = (await readdir(this.directory)).filter(file => /^[0-9a-f-]{36}\.json$/.test(file));
    const items = await Promise.all(files.map(async file => {
      const h = await this.read(file.slice(0, -5));
      return { uid: h.uid, timestamp: h.timestamp, latest_message: h.messages.at(-1) || null };
    }));
    return items.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  }
}
