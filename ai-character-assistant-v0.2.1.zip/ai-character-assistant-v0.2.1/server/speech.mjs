import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import path from 'node:path';

export function floatAudio(chunks, maximum = 16000 * 60) {
  const length = chunks.reduce((n, chunk) => n + chunk.length, 0);
  if (!length || length > maximum) throw new Error('음성은 0~60초 범위여야 합니다.');
  const buffer = Buffer.alloc(length * 4);
  let offset = 0;
  for (const chunk of chunks) for (const value of chunk) {
    if (typeof value !== 'number' || !Number.isFinite(value) || Math.abs(value) > 1.01) throw new Error('잘못된 음성 샘플입니다.');
    buffer.writeFloatLE(value, offset); offset += 4;
  }
  return buffer.toString('base64');
}

export class SpeechBridge {
  constructor({ root, timeout = 180000 } = {}) { this.root = root; this.timeout = timeout; this.pending = new Map(); this.id = 0; }
  start() {
    if (this.child) return;
    const executable = process.env.ASSISTANT_PYTHON || path.join(this.root, '.runtime/speech-venv', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');
    const child = spawn(executable, ['-u', path.join(this.root, 'server/speech_worker.py')], { cwd: this.root, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'], env: { ...process.env, PYTHONIOENCODING: 'utf-8' } });
    this.child = child;
    child.stderr.on('data', () => {});
    child.on('error', () => { this.fail(new Error('음성 실행 환경을 찾을 수 없습니다. setup-speech.ps1을 실행하세요.')); });
    child.on('exit', () => { if (this.child === child) { this.child = null; this.fail(new Error('음성 엔진이 종료되었습니다.')); } });
    createInterface({ input: child.stdout }).on('line', line => {
      let response; try { response = JSON.parse(line); } catch { return; }
      const entry = this.pending.get(response.id);
      if (!entry) return;
      entry.cleanup(); this.pending.delete(response.id);
      response.error ? entry.reject(new Error(response.error)) : entry.resolve(response.result);
    });
  }
  request(method, params, signal) {
    if (signal?.aborted) return Promise.reject(new Error('음성 요청이 중단되었습니다.'));
    this.start();
    return new Promise((resolve, reject) => {
      const id = ++this.id;
      const abort = () => { entry.cleanup(); this.pending.delete(id); reject(new Error('음성 요청이 중단되었습니다.')); };
      const timer = setTimeout(() => { abort(); }, this.timeout);
      const entry = { resolve, reject, cleanup: () => { clearTimeout(timer); signal?.removeEventListener('abort', abort); } };
      this.pending.set(id, entry);
      signal?.addEventListener('abort', abort, { once: true });
      this.child.stdin.write(JSON.stringify({ id, method, ...params }) + '\n', error => { if (error && this.pending.has(id)) { entry.cleanup(); this.pending.delete(id); reject(error); } });
    });
  }
  transcribe(chunks, { signal } = {}) { return this.request('asr', { audio: floatAudio(chunks) }, signal); }
  synthesize(text, { signal } = {}) { return this.request('tts', { text }, signal); }
  fail(error) { for (const entry of this.pending.values()) { entry.cleanup(); entry.reject(error); } this.pending.clear(); }
  close() { this.child?.kill(); this.fail(new Error('음성 엔진 종료')); }
}
