// Opt-in integration test of this application's own DOM and Electron window.
// No remote debugging port or test endpoints are opened.
import { BrowserWindow, app } from 'electron';
import { writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';
import { WindowManager } from './window-manager';
import { MenuManager } from './menu-manager';

export async function runDesktopRegression(win: BrowserWindow, manager: WindowManager, menu: MenuManager, openTestScreen: () => Promise<void>) {
  const root = process.env.ASSISTANT_PROJECT_ROOT!;
  const folder = join(root, 'test-results'); mkdirSync(folder, { recursive: true });
  const result: Record<string, unknown> = {};
  const incoming: any[] = [], outgoing: any[] = [];
  const pause = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
  const check = (value: unknown, message: string) => { if (!value) throw new Error(message); };
  const js = (script: string) => win.webContents.executeJavaScript(script, true);
  const until = async (predicate: () => unknown | Promise<unknown>, label: string, timeout = 120000) => {
    const deadline = Date.now() + timeout;
    while (!await predicate()) { if (Date.now() > deadline) throw new Error(`Timeout: ${label}`); await pause(200); }
  };
  const click = async (text: string) => { await js(`(() => { const button = [...document.querySelectorAll('button')].find(b => b.textContent.trim() === ${JSON.stringify(text)} || b.getAttribute('aria-label') === ${JSON.stringify(text)}); if (!button) throw Error('Button missing: ' + ${JSON.stringify(text)}); button.click(); })()`); await pause(200); };
  const sendText = async (text: string) => {
    await js(`(() => { const input = document.querySelector('input[placeholder="Type your message..."]'); if (!input) throw Error('Pet input missing'); input.focus(); Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, ${JSON.stringify(text)}); input.dispatchEvent(new Event('input', {bubbles:true})); })()`);
    await pause(200); await click('펫 메시지 보내기');
  };
  const completed = async (start: number) => {
    await until(() => incoming.slice(start).some(m => m.type === 'control' && m.text === 'conversation-chain-end'), 'AI completion');
    const reply = incoming.slice(start).find(m => m.type === 'audio');
    check(reply, JSON.stringify(incoming.slice(start).filter(m => m.type === 'error')) || 'No AI response');
    await until(() => js(`document.body.innerText.includes('idle')`), 'playback/idle');
    return reply;
  };
  try {
    win.webContents.debugger.attach('1.3');
    win.webContents.debugger.on('message', (_event, method, params) => {
      if (!['Network.webSocketFrameReceived', 'Network.webSocketFrameSent'].includes(method)) return;
      try {
        const value = JSON.parse(params.response.payloadData);
        if (method.endsWith('Received')) incoming.push(value); else outgoing.push({ type: value.type, images: value.images?.length });
      } catch { /* non-JSON frames are irrelevant */ }
    });
    await win.webContents.debugger.sendCommand('Network.enable');
    await until(() => js(`Boolean(window.api && window.getLAppAdapter?.().getModel()?._model && document.querySelector('canvas'))`), 'Live2D ready');
    await js(`window.__petTest = {played:0, ended:0, errors:0}; const originalPlay = HTMLMediaElement.prototype.play; HTMLMediaElement.prototype.play = function(...args) { window.__petTest.played++; this.addEventListener('ended', () => window.__petTest.ended++, {once:true}); this.addEventListener('error', () => window.__petTest.errors++, {once:true}); return originalPlay.apply(this,args); }; undefined;`);
    check(await js(`document.body.innerText.includes('마이크 켜짐')`), 'Microphone not on by default');
    await click('마이크 켜짐 · 끄기');
    const original = win.getBounds();
    // close() uses the real application's close-to-tray handler.
    for (let i = 0; i < 3; i++) {
      win.close(); check(!win.isVisible(), 'Close did not hide to tray');
      menu.setMode('pet');
      await until(() => js(`document.body.innerText.includes('AI 비서 · 펫 모드')`), 'tray pet render');
      check(win.isVisible() && win.getOpacity() === 1 && manager.getCurrentMode() === 'pet', 'Hidden-to-pet failed');
      check(win.getBounds().width <= 480 && win.getBounds().height <= 760, 'Pet not compact');
      win.close(); check(!win.isVisible(), 'Pet close did not hide');
      menu.setMode('window');
      await until(() => js(`document.body.innerText.includes('Open LLM VTuber')`), 'tray window render');
      check(win.isVisible() && win.getBounds().width === original.width, 'Window restore failed');
    }
    result.trayCycles = 3;
    menu.setMode('pet');
    await until(() => js(`document.body.innerText.includes('AI 비서 · 펫 모드')`), 'pet ready');
    check(await js(`document.body.innerText.includes('마이크 꺼짐')`), 'Mode change reset microphone preference');
    result.microphoneToggle = true;
    let start = incoming.length;
    await sendText('동작 확인입니다. 다른 설명 없이 펫 모드 연결 성공이라고만 답해주세요.');
    const reply = await completed(start);
    check(/펫.*모드.*연결.*성공/.test(reply.display_text.text), 'Pet text response mismatch');
    check(reply.audio?.length > 100, 'TTS missing');
    result.textAndTts = true;
    await openTestScreen();
    await click('펫 화면 공유');
    await until(() => js(`Boolean(document.querySelector('select[aria-label="공유할 창"]'))`), 'screen selector');
    await js(`(() => { const select = document.querySelector('select[aria-label="공유할 창"]'); const choice = [...select.options].find(o => o.text.includes('AI 비서 화면 테스트')); if (!choice) throw Error('Test screen missing'); select.value = choice.value; select.dispatchEvent(new Event('change', {bubbles:true})); })()`);
    await pause(200); await click('선택한 창 공유');
    await until(() => js(`document.body.innerText.includes('화면 공유 중지')`), 'screen capture');
    start = incoming.length;
    await sendText('첨부한 테스트 화면의 확인 코드와 도형 색/모양을 읽어줘. 다른 창이나 파일은 읽지 마.');
    const vision = await completed(start);
    check(/SKY.?4729/.test(vision.display_text.text), 'Vision code mismatch');
    check(outgoing.some(m => m.type === 'text-input' && m.images > 0), 'No captured image sent');
    check(manager.getCurrentMode() === 'pet', 'Vision unexpectedly left pet mode');
    await click('화면 공유 중지'); result.screenVision = true;
    await js(`(() => {const input=document.querySelector('input[aria-label="먼저 말하기 대기 초"]'); Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,'5'); input.dispatchEvent(new Event('input',{bubbles:true}));})()`);
    await pause(200); start = incoming.length;
    await click('먼저 말하기 시작');
    await until(() => outgoing.some(m => m.type === 'ai-speak-signal'), 'proactive timer', 20000);
    await click('먼저 말하기 중지');
    await completed(start); result.proactive = true;
    start = incoming.length;
    await click('마이크 꺼짐 · 켜기');
    await until(() => incoming.slice(start).some(m => m.type === 'user-input-transcription'), 'fake microphone VAD/ASR', 80000);
    await click('마이크 켜짐 · 끄기');
    await completed(start); result.voiceVadAsrAi = true;
    start = incoming.length;
    await sendText('승인 취소 테스트야. 현재 작업 폴더의 test-results/pet-cancel-must-not-exist.txt 파일에 테스트라고 써줘.');
    await until(() => incoming.slice(start).some(m => m.type === 'pc-approval'), 'PC approval');
    await until(() => manager.getCurrentMode() === 'window' && js(`document.body.innerText.includes('이 작업 실행')`), 'pet approval returns to window');
    await click('취소');
    await until(() => incoming.slice(start).some(m => m.type === 'control' && m.text === 'conversation-chain-end'), 'cancel completion');
    result.pcApprovalAndCancel = true;
    menu.setMode('pet');
    await until(() => js(`document.body.innerText.includes('AI 비서 · 펫 모드')`), 'final pet');
    result.playback = await js('window.__petTest');
    check((result.playback as any).played > 0 && (result.playback as any).ended > 0 && (result.playback as any).errors === 0, 'Audio playback failure');
    await js(`document.querySelector('input[placeholder="Type your message..."]').focus()`);
    await pause(300);
    writeFileSync(join(folder, 'pet-regression.png'), (await win.webContents.capturePage()).toPNG());
    result.passed = true;
  } catch (error) { result.passed = false; result.error = String(error); }
  finally {
    writeFileSync(join(folder, 'pet-regression.json'), JSON.stringify(result, null, 2));
    console.log('PET_REGRESSION', JSON.stringify(result));
    if (win.webContents.debugger.isAttached()) win.webContents.debugger.detach();
    if (process.env.ASSISTANT_TEST_QUIT === '1') app.quit();
  }
}
