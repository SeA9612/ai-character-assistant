import React, { createContext, useContext, useState, useEffect } from 'react';
import { toaster } from '../components/ui/toaster';

export type ModeType = 'window' | 'pet';

interface ModeContextType {
  mode: ModeType;
  setMode: (mode: ModeType) => void;
  isElectron: boolean;
}

const ModeContext = createContext<ModeContextType | undefined>(undefined);

export const ModeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [mode, setModeState] = useState<ModeType>('window');
  const isElectron = window.api !== undefined;

  const setMode = (newMode: ModeType) => {
    if (newMode === 'pet' && !isElectron) {
      toaster.create({
        title: "Pet mode unavailable",
        description: "Pet mode is only available in the desktop application",
        type: "info",
        duration: 2000,
      });
      return;
    }

    // Electron-specific mode change
    if (isElectron && window.api) {
      window.api.setMode(newMode).then((actual: ModeType) => setModeState(actual)).catch((error: Error) => {
        toaster.create({ title: `모드 전환 실패: ${error.message}`, type: 'error' });
      });
    } else {
      setModeState(newMode);
    }
  };

  // Listen for mode changes from main process
  useEffect(() => {
    if (isElectron && window.electron) {
      let mounted = true;
      const apply = (next: string) => {
        if (mounted && (next === 'window' || next === 'pet')) setModeState(next);
      };
      const cleanup = window.api.onModeChanged(apply);
      window.api.getMode().then(apply).catch(() => {});
      return () => { mounted = false; cleanup(); };
    }
    return undefined;
  }, [isElectron]);

  return (
    <ModeContext.Provider value={{ mode, setMode, isElectron }}>
      {children}
    </ModeContext.Provider>
  );
};

export const useMode = (): ModeContextType => {
  const context = useContext(ModeContext);
  if (context === undefined) {
    throw new Error('useMode must be used within a ModeProvider');
  }
  return context;
}; 
