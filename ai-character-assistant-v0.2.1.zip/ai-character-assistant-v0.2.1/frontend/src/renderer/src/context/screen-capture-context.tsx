import { createContext, useContext, useState, useRef, ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { toaster } from "@/components/ui/toaster";

interface ScreenCaptureContextType {
  stream: MediaStream | null;
  isStreaming: boolean;
  error: string;
  startCapture: () => Promise<void>;
  stopCapture: () => void;
}

const ScreenCaptureContext = createContext<ScreenCaptureContextType | undefined>(undefined);

export function ScreenCaptureProvider({ children }: { children: ReactNode }) {
  const { t } = useTranslation();
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState('');
  const [sources, setSources] = useState<{id:string;name:string}[]>([]);
  const [selected, setSelected] = useState('');
  const pendingSelection = useRef<((id: string | null) => void) | null>(null);
  const chooseSource = (id: string | null) => {
    pendingSelection.current?.(id);
    pendingSelection.current = null;
    setSources([]);
  };

  const startCapture = async () => {
    try {
      let mediaStream: MediaStream;

      if (window.electron) {
        const options = await window.electron.ipcRenderer.invoke('get-screen-capture');
        if (!options.length) throw new Error('공유할 창이 없습니다.');
        setSelected('');
        setSources(options);
        const sourceId = await new Promise<string | null>(resolve => { pendingSelection.current = resolve; });
        if (!sourceId) return;

        const displayMediaOptions: DisplayMediaStreamOptions = {
          video: {
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            mandatory: {
              chromeMediaSource: "desktop",
              chromeMediaSourceId: sourceId,
              minWidth: 1280,
              maxWidth: 1280,
              minHeight: 720,
              maxHeight: 720,
            },
          },
          audio: false,
        };

        mediaStream = await navigator.mediaDevices.getUserMedia(displayMediaOptions);
      } else {
        const displayMediaOptions: DisplayMediaStreamOptions = {
          video: true,
          audio: false,
        };
        mediaStream = await navigator.mediaDevices.getDisplayMedia(displayMediaOptions);
      }

      setStream(mediaStream);
      setIsStreaming(true);
      setError('');
      mediaStream.getVideoTracks()[0]?.addEventListener('ended', () => { setStream(null); setIsStreaming(false); });
    } catch (err) {
      setError(t('error.failedStartScreenCapture'));
      toaster.create({
        title: `${t('error.failedStartScreenCapture')}: ${err}`,
        type: 'error',
        duration: 2000,
      });
      console.error(err);
    }
  };

  const stopCapture = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
      setIsStreaming(false);
    }
  };

  return (
    <ScreenCaptureContext.Provider
      // eslint-disable-next-line react/jsx-no-constructed-context-values
      value={{
        stream,
        isStreaming,
        error,
        startCapture,
        stopCapture,
      }}
    >
      {children}
      {sources.length > 0 && <div role="dialog" aria-label="공유할 창 선택" style={{ position: 'fixed', inset: 0, zIndex: 100000, background: '#000a', display: 'grid', placeItems: 'center' }}>
        <div style={{ background: '#202938', color: 'white', padding: 25, borderRadius: 14, maxWidth: 520 }}>
          <h2>공유할 창 선택</h2><p>선택한 창의 이미지가 대화할 때 AI에 전달됩니다.</p>
          <select aria-label="공유할 창" value={selected} onChange={e => setSelected(e.target.value)} style={{ display: 'block', width: '100%', background: '#364154', margin: '20px 0' }}><option value="">공유할 창을 선택하세요</option>{sources.map(source => <option key={source.id} value={source.id}>{source.name}</option>)}</select>
          <button disabled={!selected} onClick={() => chooseSource(selected)} style={{ padding: 10, marginRight: 15 }}>선택한 창 공유</button><button onClick={() => chooseSource(null)} style={{ padding: 10 }}>취소</button>
        </div>
      </div>}
    </ScreenCaptureContext.Provider>
  );
}

export const useScreenCaptureContext = () => {
  const context = useContext(ScreenCaptureContext);
  if (context === undefined) {
    throw new Error('useScreenCaptureContext must be used within a ScreenCaptureProvider');
  }
  return context;
};
