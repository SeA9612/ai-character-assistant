import { useEffect, useState } from 'react';
import { Box } from '@chakra-ui/react';
import { useProactiveSpeak } from '@/context/proactive-speak-context';
import { useLocalStorage } from '@/hooks/utils/use-local-storage';
import { useWebSocket } from '@/context/websocket-context';
import { wsService } from '@/services/websocket-service';
import { useVAD } from '@/context/vad-context';
import { useMode } from '@/context/mode-context';

export function PcApprovalPanel() {
  const { wsState, sendMessage } = useWebSocket();
  const { mode, setMode } = useMode();
  const [approvals, setApprovals] = useState<Array<{ id: string; title: string; command: string }>>([]);
  useEffect(() => { if (approvals.length && mode === 'pet') setMode('window'); }, [approvals.length, mode]);
  useEffect(() => {
    if (wsState !== 'OPEN') setApprovals([]);
    const subscription = wsService.onMessage(message => {
      if (message.type === 'pc-approval' && message.id) setApprovals(items => [...items.filter(item => item.id !== message.id), { id: message.id!, title: message.title || 'PC 작업 승인', command: message.command || '' }]);
      if (message.type === 'pc-approval-closed') setApprovals(items => items.filter(item => item.id !== message.id));
    });
    return () => subscription.unsubscribe();
  }, [wsState]);
  const respond = (id: string, approved: boolean) => {
    sendMessage({ type: 'pc-approval-response', id, approved });
    setApprovals(items => items.filter(item => item.id !== id));
  };
  return <Box position="fixed" top="45px" right="12px" width="min(440px, 92vw)" zIndex={9999}>
    {approvals.map(item => <Box key={item.id} role="region" aria-label="PC 작업 승인" p="3" border="1px solid #9b80ff" borderRadius="8px" background="#202030" color="white">
      <strong>{item.title}</strong>
      <pre style={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere', maxHeight: 240, overflow: 'auto', fontSize: 12, margin: '8px 0' }}>{item.command}</pre>
      <button onClick={() => respond(item.id, true)}>이 작업 실행</button>{'　'}
      <button onClick={() => respond(item.id, false)}>취소</button>
    </Box>)}
  </Box>;
}

export default function AssistantControls() {
  const { settings, updateSettings } = useProactiveSpeak();
  const { wsState, sendMessage } = useWebSocket();
  const [voice, setVoice] = useLocalStorage('assistantVoiceEnabled', true);
  const [pc, setPc] = useLocalStorage('assistantPcEnabled', true);
  const { micOn, startMic, stopMic } = useVAD();
  useEffect(() => {
    if (wsState === 'OPEN') sendMessage({ type: 'set-speech', enabled: voice });
  }, [voice, wsState, sendMessage]);
  useEffect(() => {
    if (wsState === 'OPEN') sendMessage({ type: 'set-pc-enabled', enabled: pc });
  }, [pc, wsState, sendMessage]);
  const buttonStyle = { border: '1px solid #586275', borderRadius: 7, padding: '5px 9px', fontSize: 12, cursor: 'pointer' };
  return <Box p="3" display="flex" gap="2" flexWrap="wrap" alignItems="center" color="white">
    <button style={buttonStyle} onClick={() => setVoice(!voice)} aria-pressed={voice}>{voice ? '음성 답변 켜짐' : '음성 답변 꺼짐'}</button>
    <button style={buttonStyle} onClick={() => { if (micOn) stopMic(); else void startMic(); }} aria-pressed={micOn}>{micOn ? '마이크 켜짐 · 끄기' : '마이크 꺼짐 · 켜기'}</button>
    <button style={buttonStyle} onClick={() => setPc(!pc)} aria-pressed={pc}>{pc ? '화면·PC 작업 켜짐' : '화면·PC 작업 꺼짐'}</button>
    <button style={buttonStyle} onClick={() => sendMessage({ type: 'interrupt-signal' })}>PC 작업 중지</button>
    <button style={buttonStyle} onClick={() => updateSettings({ ...settings, allowProactiveSpeak: !settings.allowProactiveSpeak })} aria-pressed={settings.allowProactiveSpeak}>{settings.allowProactiveSpeak ? '먼저 말하기 중지' : '먼저 말하기 시작'}</button>
    <label style={{ fontSize: 12 }}>대기 초 <input aria-label="먼저 말하기 대기 초" type="number" min="5" max="3600" value={settings.idleSecondsToSpeak} onChange={e => updateSettings({ ...settings, idleSecondsToSpeak: Math.max(5, Math.min(3600, Number(e.target.value) || 60)) })} style={{ width: 55, background: '#222936', padding: 3 }} /></label>
  </Box>;
}
