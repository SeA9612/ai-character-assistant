import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import ts from '../frontend/node_modules/typescript/lib/typescript.js';

const source = await readFile(new URL('../frontend/src/main/window-manager.ts', import.meta.url), 'utf8');
const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
function setup(area = { x: 0, y: 0, width: 2560, height: 1400 }) {
  const events = [], listeners = new Map();
  const original = { x: area.x + 100, y: 100, width: 900, height: 670 };
  const state = { visible: false, opacity: 0, focusable: false, ignored: true, bounds: original, minimized: false, topmost: false };
  const win = {
    getBounds: () => ({ ...state.bounds }), setBounds: b => { state.bounds = b; },
    setOpacity: n => { state.opacity = n; }, show: () => { state.visible = true; }, focus() {},
    isMinimized: () => state.minimized, restore: () => { state.minimized = false; },
    setIgnoreMouseEvents: n => { state.ignored = n; }, setFocusable: n => { state.focusable = n; },
    setAlwaysOnTop: value => { state.topmost = value; }, setSkipTaskbar() {}, setResizable() {}, setBackgroundColor() {}, setMinimumSize() {},
    isFullScreen: () => false, webContents: { send: (...args) => events.push(args) },
  };
  const exports = {};
  vm.runInNewContext(compiled, { exports, __dirname: '.', process: { platform: 'win32' }, require: name => {
    if (name === 'electron') return { ipcMain: { on: (event, handler) => listeners.set(event, handler) }, screen: { getDisplayMatching: () => ({ workArea: area }) } };
    if (name === 'path') return { join: (...parts) => parts.join('/') };
    if (name === '@electron-toolkit/utils') return { is: { dev: false } };
    throw new Error(name);
  } });
  const manager = new exports.WindowManager(); manager.window = win;
  return { manager, state, events, listeners, original };
}
test('hidden tray mode changes complete without renderer frames and restore original window bounds', () => {
  const { manager, state, events, original, listeners } = setup();
  manager.setWindowMode('pet');
  assert.equal(manager.getCurrentMode(), 'pet');
  assert.equal(state.visible, true); assert.equal(state.opacity, 1);
  assert.equal(state.focusable, true); assert.equal(state.ignored, false);
  assert.equal(state.topmost, true);
  assert.equal(state.bounds.width, 480); assert.equal(state.bounds.height, 760);
  assert.equal(listeners.has('renderer-ready-for-mode-change'), false);
  assert.ok(events.some(event => event[0] === 'mode-changed' && event[1] === 'pet'));
  for (let i = 0; i < 3; i++) {
    state.visible = false; manager.setWindowMode('window');
    assert.equal(state.visible, true); assert.deepEqual(state.bounds, original); assert.equal(state.topmost, false);
    state.visible = false; manager.setWindowMode('pet'); assert.equal(state.visible, true);
  }
  state.visible = false; state.minimized = true; manager.setWindowMode('pet');
  assert.equal(state.visible, true); assert.equal(state.minimized, false);
});
test('negative monitor coordinates and passthrough reset keep pet controls usable', () => {
  const area = { x: -1920, y: -200, width: 1920, height: 1040 };
  const { manager, state } = setup(area);
  manager.setWindowMode('pet');
  assert.ok(state.bounds.x >= area.x && state.bounds.x + state.bounds.width <= area.x + area.width);
  assert.ok(state.bounds.y >= area.y && state.bounds.y + state.bounds.height <= area.y + area.height);
  manager.updateComponentHover('input', false); assert.equal(state.ignored, false);
  manager.toggleForceIgnoreMouse(); assert.equal(state.ignored, true);
  manager.setWindowMode('pet'); assert.equal(state.ignored, false);
  manager.toggleForceIgnoreMouse(); assert.equal(state.ignored, true);
  manager.setWindowMode('window'); manager.setWindowMode('pet');
  assert.equal(state.ignored, false); assert.equal(manager.isForceIgnoreMouse(), false);
});
