import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { mkdir, mkdtemp, readFile } from 'node:fs/promises';
import { once } from 'node:events';
import WebSocket from 'ws';
import { PcTools } from '../server/pc.mjs';
import { CodexBridge } from '../server/codex.mjs';
import { createAssistant, ROOT } from '../server/main.mjs';

test('PC mutations require exact review and cancellation prevents any execution', async () => {
  let calls = 0;
  const pc = new PcTools({ root: ROOT, run: async () => { calls++; return { output: 'done' }; } });
  const args = { action: 'powershell', script: "Write-Output 'ok'", reason: '테스트' };
  await assert.rejects(pc.execute(args), /취소/);
  assert.equal(calls, 0);
  const result = await pc.execute(args, { approve: async details => { assert.equal(details.command, args.script); return true; } });
  assert.equal(result.success, true);
  assert.equal(calls, 1);
  await assert.rejects(pc.execute({ action: 'click', x: 10, y: 10, reason: '테스트' }), /handle/);
  const controller = new AbortController(); controller.abort();
  await assert.rejects(pc.execute(args, { signal: controller.signal, approve: async () => true }), /중단/);
  assert.equal(calls, 1);
});

test('Codex dynamic PC tool roundtrip returns real tool result and cleans up handlers', async t => {
  const bridge = new CodexBridge({ root: ROOT, command: process.execPath, args: [path.join(ROOT, 'tests/fixtures/codex-fake.mjs')], timeout: 1000 });
  t.after(() => bridge.close());
  let calls = 0;
  const reply = await bridge.generate({ messages: [{ role: 'human', content: 'tool-test' }], onTool: async args => { calls++; assert.equal(args.action, 'powershell'); return { success: true, contentItems: [{ type: 'inputText', text: 'file exists' }] }; } });
  assert.equal(reply, 'PC 실행 확인');
  assert.equal(calls, 1);
  assert.equal(bridge.toolHandlers.size, 0);
  assert.equal(await bridge.generate({ messages: [{ role: 'human', content: 'tool-test' }] }), '[joy] 연결 성공');
  assert.equal(calls, 1);
});

test('PC approval bypasses chat queue; disabled mode and proactive turns have no tools', async t => {
  await mkdir(path.join(ROOT, '.runtime/tests'), { recursive: true });
  let executions = 0;
  let accept = true;
  const options = [];
  const pc = new PcTools({ root: ROOT, run: async () => { executions++; return { output: 'done' }; } });
  const bridge = { close() {}, async generate(opts) {
    options.push(opts);
    if (opts.onTool) {
      const invoke = () => opts.onTool({ action: 'powershell', script: "Write-Output 'ok'", reason: '테스트' });
      if (opts.messages.at(-1).content === '거절테스트') {
        await assert.rejects(invoke(), /취소/);
        await assert.rejects(invoke(), /거절/);
      } else await invoke();
    }
    return '완료';
  } };
  const speech = { async transcribe() { return { text: '음성작업요청' }; }, async synthesize() { return { audio: 'AA==' }; }, close() {} };
  const app = createAssistant({ bridge, pc, speech, port: 0, historyDirectory: await mkdtemp(path.join(ROOT, '.runtime/tests/pc-')) });
  const port = await app.listen(); t.after(() => app.close());
  const ws = new WebSocket(`ws://127.0.0.1:${port}/client-ws`); t.after(() => ws.close());
  const messages = [];
  ws.on('message', data => { const m = JSON.parse(data); messages.push(m); if (m.type === 'pc-approval') ws.send(JSON.stringify({ type: 'pc-approval-response', id: m.id, approved: accept })); });
  await once(ws, 'open');
  const wait = async predicate => { const until = Date.now() + 4000; while (!predicate()) { if (Date.now() > until) throw new Error('event timeout'); await new Promise(r => setTimeout(r, 10)); } };
  ws.send(JSON.stringify({ type: 'text-input', text: '실행 테스트' }));
  await wait(() => messages.some(m => m.type === 'audio'));
  assert.equal(executions, 1);
  assert.ok(messages.some(m => m.type === 'tool_call_status' && m.status === 'completed'));
  ws.send(JSON.stringify({ type: 'set-pc-enabled', enabled: false }));
  ws.send(JSON.stringify({ type: 'text-input', text: '대화 전용' }));
  await wait(() => options.length === 2);
  assert.equal(options[1].onTool, null);
  ws.send(JSON.stringify({ type: 'set-pc-enabled', enabled: true }));
  ws.send(JSON.stringify({ type: 'ai-speak-signal', idle_time: 5 }));
  await wait(() => options.length === 3);
  assert.equal(options[2].onTool, null);
  assert.equal(executions, 1);
  ws.send(JSON.stringify({ type: 'mic-audio-data', audio: [0] }));
  ws.send(JSON.stringify({ type: 'mic-audio-end' }));
  await wait(() => executions === 2);
  assert.equal(options[3].messages.at(-1).content, '음성작업요청');
  accept = false;
  ws.send(JSON.stringify({ type: 'text-input', text: '거절테스트' }));
  await wait(() => messages.some(m => m.type === 'tool_call_status' && m.status === 'error'));
  assert.equal(executions, 2);
});

test('Windows worker executes an approved file task and returns UTF-8 output', { skip: process.platform !== 'win32' }, async () => {
  await mkdir(path.join(ROOT, '.runtime/tests'), { recursive: true });
  const folder = await mkdtemp(path.join(ROOT, '.runtime/tests/native-pc-'));
  const target = path.join(folder, 'result.txt');
  const quote = target.replaceAll("'", "''");
  const pc = new PcTools({ root: ROOT });
  const result = await pc.execute({ action: 'powershell', reason: '파일 생성 검증', script: `Set-Content -LiteralPath '${quote}' -Value '테스트 성공' -Encoding UTF8; Get-Content -LiteralPath '${quote}' -Encoding UTF8` }, { approve: async () => true });
  assert.equal(result.success, true);
  assert.match(await readFile(target, 'utf8'), /테스트 성공/);
  assert.match(result.contentItems[0].text, /테스트 성공/);
  const windows = await pc.execute({ action: 'windows', reason: '창 목록 검증' });
  assert.ok(Array.isArray(JSON.parse(windows.contentItems[0].text).windows));
});
