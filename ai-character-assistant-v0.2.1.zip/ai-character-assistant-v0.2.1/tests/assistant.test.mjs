import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile } from 'node:fs/promises';
import path from 'node:path';
import { once } from 'node:events';
import WebSocket from 'ws';
import { createAssistant, ROOT } from '../server/main.mjs';
import { CodexBridge, MockBridge } from '../server/codex.mjs';
import { HistoryStore } from '../server/history.mjs';
import { floatAudio } from '../server/speech.mjs';
import { cleanReply } from '../server/text.mjs';

await mkdir(path.join(ROOT, '.runtime/tests'), { recursive: true });
const temporary = () => mkdtemp(path.join(ROOT, '.runtime/tests/run-'));

test('character subtitles and speech strip Markdown emphasis but preserve literal symbols', () => {
  assert.equal(cleanReply('[joy] 도형은 **파란색 정사각형**과 **빨간색 원**이고, 코드는 **SKY-4729**입니다.'), '도형은 파란색 정사각형과 빨간색 원이고, 코드는 SKY-4729입니다.');
  assert.equal(cleanReply('별표 * 하나, 계산 3 * 4, 배열 [1]'), '별표 * 하나, 계산 3 * 4, 배열 [1]');
  assert.equal(cleanReply('코드는 `SKY-4729`, __확인__ 완료'), '코드는 SKY-4729, 확인 완료');
});

test('history survives restart and blocks path traversal', async () => {
  const directory = await temporary();
  const store = new HistoryStore(directory);
  const h = await store.create();
  h.messages.push({ role: 'human', content: '안녕', timestamp: h.timestamp });
  await store.save(h);
  assert.deepEqual((await new HistoryStore(directory).read(h.uid)).messages, h.messages);
  assert.equal((await store.list())[0].latest_message.content, '안녕');
  await assert.rejects(store.read('../../secret'), /잘못된/);
});

test('Codex RPC streams a completed response and does not expose identity', async t => {
  const bridge = new CodexBridge({ root: ROOT, command: process.execPath, args: [path.join(ROOT, 'tests/fixtures/codex-fake.mjs')], timeout: 1000 });
  t.after(() => bridge.close());
  const status = await bridge.status();
  assert.equal(status.authenticated, true);
  assert.equal(JSON.stringify(status).includes('private@'), false);
  const deltas = [];
  assert.equal(await bridge.generate({ messages: [{ role: 'human', content: 'hello' }], onDelta: x => deltas.push(x) }), '[joy] 연결 성공');
  assert.equal(deltas.length, 2);
  await assert.rejects(bridge.generate({ messages: [{ role: 'human', content: 'fail' }] }), /expected failure/);
});

test('separately billed API-key authentication is refused', async t => {
  const bridge = new CodexBridge({ root: ROOT, command: process.execPath, args: [path.join(ROOT, 'tests/fixtures/codex-fake.mjs'), '--api-key'] });
  t.after(() => bridge.close());
  assert.equal((await bridge.status()).apiKeyRejected, true);
  await assert.rejects(bridge.generate({ messages: [{ role: 'human', content: 'hello' }] }), /API 키 로그인/);
});

test('Codex turn can be interrupted and times out without leaking listeners', async t => {
  const bridge = new CodexBridge({ root: ROOT, command: process.execPath, args: [path.join(ROOT, 'tests/fixtures/codex-fake.mjs')], timeout: 300 });
  t.after(() => bridge.close());
  const controller = new AbortController();
  const pending = bridge.generate({ messages: [{ role: 'human', content: 'wait' }], signal: controller.signal });
  setTimeout(() => controller.abort(), 100);
  await assert.rejects(pending, /중단/);
  await assert.rejects(bridge.generate({ messages: [{ role: 'human', content: 'wait' }] }), /시간 초과/);
  assert.equal(bridge.listenerCount('notification'), 0);
});

function collect(ws) {
  const messages = [], waiting = [];
  ws.on('message', data => {
    const value = JSON.parse(data);
    messages.push(value);
    for (const waiter of [...waiting]) if (waiter.predicate(value)) { waiting.splice(waiting.indexOf(waiter), 1); clearTimeout(waiter.timer); waiter.resolve(value); }
  });
  return {
    messages,
    next(predicate) { return new Promise((resolve, reject) => { const w = { predicate, resolve }; w.timer = setTimeout(() => { waiting.splice(waiting.indexOf(w), 1); reject(new Error('WebSocket event timeout')); }, 4000); waiting.push(w); }); },
  };
}

test('HTTP assets, WebSocket chat, saved history, malformed input and origin protection', async t => {
  const directory = await temporary();
  const app = createAssistant({ bridge: new MockBridge(), port: 0, historyDirectory: directory });
  const port = await app.listen();
  const base = `http://127.0.0.1:${port}`;
  t.after(() => app.close());
  assert.equal((await (await fetch(base + '/health')).json()).mode, 'mock');
  assert.equal((await fetch(base + '/live2d-models/mao_pro/runtime/mao_pro.model3.json')).status, 200);
  assert.equal((await fetch(base + '/api/status', { headers: { Origin: 'https://untrusted.invalid' } })).status, 403);
  assert.equal((await fetch(base + '/api/status', { headers: { Origin: 'null' } })).status, 403);
  assert.equal((await fetch(base + '/.runtime/history')).status, 404);
  assert.equal((await fetch(base + '/live2d-models/%2e%2e%2f%2e%2e%2fREADME.md')).status, 404);
  const ws = new WebSocket(`ws://127.0.0.1:${port}/client-ws`);
  const events = collect(ws);
  t.after(() => ws.close());
  await once(ws, 'open');
  const created = events.next(m => m.type === 'new-history-created');
  ws.send(JSON.stringify({ type: 'create-new-history' }));
  const { history_uid: uid } = await created;
  const done = events.next(m => m.type === 'control' && m.text === 'conversation-chain-end');
  ws.send(JSON.stringify({ type: 'text-input', text: '안녕' }));
  await done;
  assert.match(events.messages.find(m => m.type === 'audio').display_text.text, /로컬 테스트/);
  const saved = JSON.parse(await readFile(path.join(directory, uid + '.json'), 'utf8'));
  assert.deepEqual(saved.messages.map(m => m.role), ['human', 'ai']);
  const malformed = events.next(m => m.type === 'error'); ws.send('not json'); await malformed;
  const invalidImage = events.next(m => m.type === 'error');
  ws.send(JSON.stringify({ type: 'text-input', text: 'image', images: [{ data: 'file:///private' }] }));
  assert.match((await invalidImage).message, /이미지/);
  const history = events.next(m => m.type === 'history-data');
  ws.send(JSON.stringify({ type: 'fetch-and-set-history', history_uid: uid }));
  assert.equal((await history).messages.length, 2);
});

test('interrupt bypasses message queue and stops a running response', async t => {
  class SlowBridge extends MockBridge {
    generate({ signal }) { return new Promise((resolve, reject) => signal.addEventListener('abort', () => reject(new Error('aborted')), { once: true })); }
  }
  const app = createAssistant({ bridge: new SlowBridge(), port: 0, historyDirectory: await temporary() });
  const port = await app.listen();
  t.after(() => app.close());
  const ws = new WebSocket(`ws://127.0.0.1:${port}/client-ws`), events = collect(ws);
  t.after(() => ws.close());
  await once(ws, 'open');
  const started = events.next(m => m.type === 'control' && m.text === 'conversation-chain-start');
  ws.send(JSON.stringify({ type: 'text-input', text: 'wait' }));
  await started;
  const stopped = events.next(m => m.type === 'control' && m.text === 'conversation-chain-end');
  ws.send(JSON.stringify({ type: 'interrupt-signal' }));
  await stopped;
  assert.equal(events.messages.some(m => m.type === 'audio'), false);
});

test('audio sample encoding validates duration and sample values', () => {
  const bytes = Buffer.from(floatAudio([[0, 0.5], [-0.25]]), 'base64');
  assert.equal(bytes.readFloatLE(4), 0.5);
  assert.equal(bytes.readFloatLE(8), -0.25);
  assert.throws(() => floatAudio([[Infinity]]), /잘못된/);
  assert.throws(() => floatAudio([[2]]), /잘못된/);
  assert.throws(() => floatAudio([[0, 0]], 1), /60초/);
});

test('microphone frames run ASR, AI, WAV response; visual inputs and proactive rate limit work', async t => {
  const image = { source: 'screen', mime_type: 'image/png', data: 'data:image/png;base64,aGVsbG8=' };
  const calls = [];
  class VisualBridge extends MockBridge {
    async generate(input) { calls.push(input); return '[joy] 음성 **답변**입니다.'; }
  }
  const speech = {
    async transcribe(chunks) { assert.deepEqual(chunks, [[0, 0.1, -0.1]]); return { text: '음성 질문입니다.' }; },
    async synthesize(text) { assert.equal(text, '음성 답변입니다.'); return { audio: Buffer.from('RIFFtest').toString('base64') }; },
    close() {},
  };
  const app = createAssistant({ bridge: new VisualBridge(), speech, port: 0, historyDirectory: await temporary() });
  const port = await app.listen(); t.after(() => app.close());
  const ws = new WebSocket(`ws://127.0.0.1:${port}/client-ws`), events = collect(ws);
  t.after(() => ws.close()); await once(ws, 'open');
  const done = events.next(m => m.type === 'audio');
  ws.send(JSON.stringify({ type: 'mic-audio-data', audio: [0, 0.1, -0.1] }));
  ws.send(JSON.stringify({ type: 'mic-audio-end', images: [image] }));
  const output = await done;
  assert.equal(Buffer.from(output.audio, 'base64').subarray(0, 4).toString(), 'RIFF');
  assert.equal(events.messages.find(m => m.type === 'user-input-transcription').text, '음성 질문입니다.');
  assert.deepEqual(calls[0].images, [image]);
  const proactive = events.next(m => m.type === 'audio');
  ws.send(JSON.stringify({ type: 'ai-speak-signal', idle_time: 5, images: [image] }));
  await proactive;
  ws.send(JSON.stringify({ type: 'ai-speak-signal', idle_time: 5, images: [image] }));
  const listed = events.next(m => m.type === 'history-list');
  ws.send(JSON.stringify({ type: 'fetch-history-list' })); await listed;
  assert.equal(calls.length, 2);
});

test('TTS failure preserves text reply and closes conversation normally', async t => {
  const speech = { async synthesize() { throw new Error('offline'); }, close() {} };
  const app = createAssistant({ bridge: new MockBridge(), speech, port: 0, historyDirectory: await temporary() });
  const port = await app.listen(); t.after(() => app.close());
  const ws = new WebSocket(`ws://127.0.0.1:${port}/client-ws`), events = collect(ws);
  t.after(() => ws.close()); await once(ws, 'open');
  const done = events.next(m => m.type === 'control' && m.text === 'conversation-chain-end');
  ws.send(JSON.stringify({ type: 'text-input', text: 'tts error' })); await done;
  assert.match(events.messages.find(m => m.type === 'error').message, /음성 생성 실패/);
  assert.match(events.messages.find(m => m.type === 'audio').display_text.text, /로컬 테스트/);
});
