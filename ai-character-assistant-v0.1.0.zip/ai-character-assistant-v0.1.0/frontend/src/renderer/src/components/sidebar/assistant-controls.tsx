import { useEffect } from 'react';
import { Box } from '@chakra-ui/react';
import { useProactiveSpeak } from '@/context/proactive-speak-context';
import { useLocalStorage } from '@/hooks/utils/use-local-storage';
import { useWebSocket } from '@/context/websocket-context';

export default function AssistantControls() {
  const { settings, updateSettings } = useProactiveSpeak();
  const { wsState, sendMessage } = useWebSocket();
  const [voice, setVoice] = useLocalStorage('assistantVoiceEnabled', true);
  useEffect(() => {
    if (wsState === 'OPEN') sendMessage({ type: 'set-speech', enabled: voice });
  }, [voice, wsState, sendMessage]);
  const buttonStyle = { border: '1px solid #586275', borderRadius: 7, padding: '5px 9px', fontSize: 12, cursor: 'pointer' };
  return <Box p="3" display="flex" gap="2" flexWrap="wrap" alignItems="center">
    <button style={buttonStyle} onClick={() => setVoice(!voice)} aria-pressed={voice}>{voice ? '음성 답변 켜짐' : '음성 답변 꺼짐'}</button>
    <button style={buttonStyle} onClick={() => updateSettings({ ...settings, allowProactiveSpeak: !settings.allowProactiveSpeak })} aria-pressed={settings.allowProactiveSpeak}>{settings.allowProactiveSpeak ? '먼저 말하기 중지' : '먼저 말하기 시작'}</button>
    <label style={{ fontSize: 12 }}>대기 초 <input aria-label="먼저 말하기 대기 초" type="number" min="5" max="3600" value={settings.idleSecondsToSpeak} onChange={e => updateSettings({ ...settings, idleSecondsToSpeak: Math.max(5, Math.min(3600, Number(e.target.value) || 60)) })} style={{ width: 55, background: '#222936', padding: 3 }} /></label>
  </Box>;
}
