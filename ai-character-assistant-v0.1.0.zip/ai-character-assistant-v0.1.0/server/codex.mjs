import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { EventEmitter } from 'node:events';
import { mkdir } from 'node:fs/promises';
import path from 'node:path';

export class CodexBridge extends EventEmitter {
  constructor({ root, command = process.env.CODEX_BINARY || 'codex', args, timeout = 180000 } = {}) {
    super();
    this.root = root;
    this.command = command;
    this.args = args;
    this.timeout = timeout;
    this.pending = new Map();
    this.nextId = 1;
  }
  async start() {
    if (this.starting) return this.starting;
    this.starting = this.initialize().catch(error => { this.starting = null; this.close(); throw error; });
    return this.starting;
  }
  async initialize() {
    const cwd = path.join(this.root, '.runtime', 'agent');
    await mkdir(cwd, { recursive: true });
    const env = { ...process.env };
    // Keep this app's login separate from the developer's global Codex account.
    env.CODEX_HOME = path.join(this.root, '.runtime', 'codex');
    await mkdir(env.CODEX_HOME, { recursive: true });
    // Never silently switch to separately billed API-key usage.
    delete env.OPENAI_API_KEY;
    delete env.CODEX_API_KEY;
    const args = this.args || ['app-server', '--listen', 'stdio://',
      '-c', 'cli_auth_credentials_store="file"',
      '-c', 'approval_policy="never"', '-c', 'sandbox_mode="read-only"',
      '-c', 'web_search="disabled"', '-c', 'features.shell_tool=false',
      '-c', 'features.apps=false', '-c', 'features.browser_use=false',
      '-c', 'features.computer_use=false', '-c', 'features.multi_agent=false',
      '-c', 'features.code_mode=false',
      '-c', 'mcp_servers={}'];
    this.child = spawn(this.command, args, { cwd, env, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    // Stderr may contain account or configuration details: do not expose it to the browser.
    this.child.stderr.on('data', () => {});
    this.child.on('error', error => this.fail(new Error(`Codex 실행 실패 (${error.code || 'unknown'}). CODEX_BINARY 설정을 확인하세요.`)));
    const child = this.child;
    this.child.on('exit', () => { if (this.child === child) { this.starting = null; this.fail(new Error('Codex 연결이 종료되었습니다. 다시 연결해주세요.')); } });
    createInterface({ input: this.child.stdout }).on('line', line => {
      let message;
      try { message = JSON.parse(line); } catch { return; }
      if (message.id !== undefined && !message.method) {
        const request = this.pending.get(message.id);
        if (!request) return;
        this.pending.delete(message.id);
        clearTimeout(request.timer);
        if (message.error) request.reject(new Error(message.error.message || 'Codex 요청 실패'));
        else request.resolve(message.result);
      } else if (message.id !== undefined) {
        // This character client does not approve tools, shell commands or file writes.
        this.write({ id: message.id, error: { code: -32601, message: 'Tools are disabled in this client' } });
      } else if (message.method) this.emit('notification', message);
    });
    await this.request('initialize', { clientInfo: { name: 'ai_character_assistant', title: 'AI 캐릭터 비서', version: '0.1.0' } });
    this.write({ method: 'initialized', params: {} });
  }
  write(message) {
    if (!this.child?.stdin.writable) throw new Error('Codex에 연결되지 않았습니다.');
    this.child.stdin.write(JSON.stringify(message) + '\n');
  }
  request(method, params = {}) {
    return new Promise((resolve, reject) => {
      const id = this.nextId++;
      const timer = setTimeout(() => { this.pending.delete(id); reject(new Error(`Codex ${method} 응답 시간 초과`)); }, Math.min(this.timeout, 30000));
      this.pending.set(id, { resolve, reject, timer });
      try { this.write({ id, method, params }); } catch (error) { clearTimeout(timer); this.pending.delete(id); reject(error); }
    });
  }
  fail(error) {
    for (const item of this.pending.values()) { clearTimeout(item.timer); item.reject(error); }
    this.pending.clear();
    this.emit('bridge-error', error);
  }
  async status() {
    await this.start();
    const result = await this.request('account/read', { refreshToken: false });
    const account = result.account;
    return { mode: 'codex', authenticated: ['chatgpt', 'chatgptAuthTokens'].includes(account?.type),
      authType: account?.type || null, plan: account?.planType || null,
      needsLogin: !account, apiKeyRejected: account?.type === 'apiKey' };
  }
  async login() {
    await this.start();
    const result = await this.request('account/login/start', { type: 'chatgpt' });
    return { authUrl: result.authUrl, loginId: result.loginId };
  }
  async models() {
    await this.start();
    const result = await this.request('model/list', {});
    return (result.data || []).map(item => ({ id: item.model || item.id, name: item.displayName, isDefault: item.isDefault }));
  }
  async generate({ messages, images = [], signal, onDelta = () => {} }) {
    const status = await this.status();
    if (!status.authenticated) throw new Error(status.apiKeyRejected ? 'API 키 로그인은 사용할 수 없습니다. ChatGPT로 로그인해주세요.' : '먼저 설정 화면에서 ChatGPT로 로그인해주세요.');
    const models = await this.models();
    const model = process.env.ASSISTANT_MODEL || models.find(item => item.isDefault)?.id || models[0]?.id;
    if (!model) throw new Error('사용 가능한 구독 모델이 없습니다.');
    const started = await this.request('thread/start', {
      model, cwd: path.join(this.root, '.runtime', 'agent'), ephemeral: true,
      sandbox: 'read-only', approvalPolicy: 'never',
      baseInstructions: '당신은 친절한 AI 캐릭터 비서입니다. 한국어로 자연스럽고 간결하게 답하세요. 필요하면 문장 앞에 [joy], [sadness], [surprise], [neutral] 감정 태그 하나를 쓰세요. 이 클라이언트에서는 도구를 사용하거나 파일에 접근하지 마세요. 답변만 작성하세요.',
      developerInstructions: '주어진 대화만 참고하세요. 도구 호출, 파일 읽기/쓰기, 명령 실행은 허용되지 않습니다.',
    });
    const threadId = started.thread.id;
    if (signal?.aborted) throw new Error('대화가 중단되었습니다.');
    const input = [{ type: 'text', text: messages.map(m => `${m.role === 'human' ? '사용자' : '비서'}: ${m.content}`).join('\n\n') },
      ...images.map(image => ({ type: 'image', url: image.data }))];
    return new Promise((resolve, reject) => {
      let result = '', turnId, settled = false;
      const finish = (error) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        this.off('notification', listener);
        this.off('bridge-error', failure);
        signal?.removeEventListener('abort', abort);
        error ? reject(error) : resolve(result);
      };
      const interrupt = () => turnId && this.request('turn/interrupt', { threadId, turnId }).catch(() => {});
      const abort = () => { interrupt(); finish(new Error('대화가 중단되었습니다.')); };
      const failure = error => finish(error);
      const timer = setTimeout(() => { interrupt(); finish(new Error('AI 답변 시간 초과')); }, this.timeout);
      const listener = ({ method, params: p = {} }) => {
        if (p.threadId !== threadId) return;
        if (method === 'item/agentMessage/delta') { result += p.delta || ''; onDelta(result); }
        if (method === 'item/completed' && p.item?.type === 'agentMessage' && !result) { result = p.item.text || ''; onDelta(result); }
        if (method === 'turn/completed') {
          const state = p.turn?.status;
          finish(state === 'completed' ? (result.trim() ? null : new Error('AI가 빈 응답을 반환했습니다.')) : new Error(p.turn?.error?.message || `대화 종료: ${state}`));
        }
      };
      this.on('notification', listener);
      this.on('bridge-error', failure);
      signal?.addEventListener('abort', abort, { once: true });
      this.request('turn/start', { threadId, input }).then(({ turn }) => {
        turnId = turn.id;
        if (signal?.aborted) interrupt();
      }).catch(finish);
      if (signal?.aborted) abort();
    }).finally(() => this.request('thread/unsubscribe', { threadId }).catch(() => {}));
  }
  close() {
    this.child?.kill();
    this.fail(new Error('Codex 클라이언트 종료'));
    this.starting = null;
  }
}

export class MockBridge {
  async status() { return { mode: 'mock', authenticated: false, plan: null }; }
  async models() { return []; }
  async login() { throw new Error('로컬 테스트 모드에서는 로그인하지 않습니다.'); }
  async generate({ messages, signal, onDelta = () => {} }) {
    const result = `[joy] 로컬 테스트 응답입니다. 입력한 내용: ${messages.at(-1).content}`;
    if (signal?.aborted) throw new Error('대화가 중단되었습니다.');
    onDelta(result);
    return result;
  }
  close() {}
}
