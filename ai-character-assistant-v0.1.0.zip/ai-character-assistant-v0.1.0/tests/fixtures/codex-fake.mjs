import { createInterface } from 'node:readline';
const send = message => process.stdout.write(JSON.stringify(message) + '\n');
createInterface({ input: process.stdin }).on('line', line => {
  const { id, method, params } = JSON.parse(line);
  if (id === undefined) return;
  let result = {};
  if (method === 'account/read') result = { account: { type: process.argv.includes('--api-key') ? 'apiKey' : 'chatgpt', planType: 'plus', email: 'private@example.invalid' } };
  if (method === 'model/list') result = { data: [{ id: 'test-model', model: 'test-model', isDefault: true }] };
  if (method === 'thread/start') result = { thread: { id: 'thread-test' } };
  if (method === 'turn/start') {
    result = { turn: { id: 'turn-test' } };
    const text = params.input[0].text;
    if (!text.includes('wait')) setTimeout(() => {
      send({ method: 'item/agentMessage/delta', params: { threadId: 'thread-test', delta: '[joy] 연결 ' } });
      send({ method: 'item/agentMessage/delta', params: { threadId: 'thread-test', delta: '성공' } });
      send({ method: 'turn/completed', params: { threadId: 'thread-test', turn: { status: text.includes('fail') ? 'failed' : 'completed', error: { message: 'expected failure' } } } });
    }, 15);
  }
  send({ id, result });
});
