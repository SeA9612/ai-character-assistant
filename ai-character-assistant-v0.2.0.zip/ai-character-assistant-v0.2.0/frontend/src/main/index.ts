/* eslint-disable no-shadow */
import { app, ipcMain, globalShortcut, desktopCapturer, BrowserWindow } from "electron";
import { join } from 'path';
import { writeFileSync } from 'fs';
import { electronApp, optimizer } from "@electron-toolkit/utils";
import { WindowManager } from "./window-manager";
import { MenuManager } from "./menu-manager";

let windowManager: WindowManager;
let menuManager: MenuManager;
let isQuitting = false;
let testScreenWindow: BrowserWindow | null = null;
app.setName('AI 캐릭터 비서');
app.commandLine.appendSwitch('force-renderer-accessibility');
if (process.env.ASSISTANT_FAKE_MIC) {
  // Explicit developer test mode: only a generated WAV, never the user's microphone.
  app.commandLine.appendSwitch('use-fake-device-for-media-stream');
  app.commandLine.appendSwitch('use-file-for-fake-audio-capture', process.env.ASSISTANT_FAKE_MIC);
  app.commandLine.appendSwitch('use-fake-ui-for-media-stream');
}
if (process.env.ASSISTANT_PROJECT_ROOT) app.setPath('userData', join(process.env.ASSISTANT_PROJECT_ROOT, '.runtime', process.env.ASSISTANT_FAKE_MIC ? 'desktop-test-profile' : 'desktop-profile'));

function recordDesktopState(): void {
  if (!process.env.ASSISTANT_PROJECT_ROOT) return;
  writeFileSync(join(process.env.ASSISTANT_PROJECT_ROOT, '.runtime/desktop-state.json'), JSON.stringify({
    testScreenRequested: process.env.ASSISTANT_OPEN_TEST_SCREEN,
    fakeMicrophone: !!process.env.ASSISTANT_FAKE_MIC,
    mode: windowManager?.getCurrentMode(),
    windows: BrowserWindow.getAllWindows().map(window => ({ title: window.getTitle(), visible: window.isVisible(), bounds: window.getBounds(), alwaysOnTop: window.isAlwaysOnTop(), url: window.webContents.getURL() })),
  }, null, 2));
}

async function openTestScreen(): Promise<void> {
  if (testScreenWindow && !testScreenWindow.isDestroyed()) { testScreenWindow.show(); testScreenWindow.focus(); return; }
  testScreenWindow = new BrowserWindow({ width: 720, height: 580, show: false, title: 'AI 비서 화면 테스트', webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true } });
  testScreenWindow.on('closed', () => { testScreenWindow = null; });
  testScreenWindow.show();
  testScreenWindow.focus();
  if (process.env.ASSISTANT_PROJECT_ROOT) await testScreenWindow.loadFile(join(process.env.ASSISTANT_PROJECT_ROOT, 'server/public/test-screen.html'));
  else await testScreenWindow.loadURL('http://127.0.0.1:12393/test-screen/');
  // A Windows SW_HIDE launch can consume the first ShowWindow request.
  testScreenWindow.show();
  testScreenWindow.focus();
}

function setupIPC(): void {
  ipcMain.handle("get-platform", () => process.platform);

  ipcMain.on("set-ignore-mouse-events", (_event, ignore: boolean) => {
    const window = windowManager.getWindow();
    if (window) {
      windowManager.setIgnoreMouseEvents(ignore);
    }
  });

  ipcMain.on("get-current-mode", (event) => {
    event.returnValue = windowManager.getCurrentMode();
  });

  ipcMain.on("pre-mode-changed", (_event, newMode) => {
    if (newMode === 'window' || newMode === 'pet') {
      menuManager.setMode(newMode);
    }
  });

  ipcMain.on("window-minimize", () => {
    windowManager.getWindow()?.minimize();
  });

  ipcMain.on("window-maximize", () => {
    const window = windowManager.getWindow();
    if (window) {
      windowManager.maximizeWindow();
    }
  });

  ipcMain.on("window-close", () => {
    const window = windowManager.getWindow();
    if (window) {
      if (process.platform === "darwin") {
        window.hide();
      } else {
        window.close();
      }
    }
  });

  ipcMain.on(
    "update-component-hover",
    (_event, componentId: string, isHovering: boolean) => {
      windowManager.updateComponentHover(componentId, isHovering);
    },
  );

  ipcMain.handle("get-config-files", () => {
    const configFiles = [];
    menuManager.updateConfigFiles(configFiles);
    return configFiles;
  });

  ipcMain.on("update-config-files", (_event, files) => {
    menuManager.updateConfigFiles(files);
  });

  ipcMain.handle('get-screen-capture', async () => {
    const sources = await desktopCapturer.getSources({ types: ['window', 'screen'], thumbnailSize: { width: 0, height: 0 } });
    const choices = sources.map(source => ({ id: source.id, name: source.name }));
    // Electron 31 can omit its own windows from enumeration on Windows.
    if (testScreenWindow && !testScreenWindow.isDestroyed() && testScreenWindow.isVisible()) {
      const id = testScreenWindow.getMediaSourceId();
      if (!choices.some(source => source.id === id)) choices.unshift({ id, name: testScreenWindow.getTitle() });
    }
    return choices;
  });
  ipcMain.handle('open-test-screen', async () => {
    await openTestScreen();
  });
}

app.whenReady().then(() => {
  electronApp.setAppUserModelId("com.electron");

  windowManager = new WindowManager();
  menuManager = new MenuManager((mode) => windowManager.setWindowMode(mode));

  const window = windowManager.createWindow({
    titleBarOverlay: {
      color: "#111111",
      symbolColor: "#FFFFFF",
      height: 30,
    },
  });
  window.webContents.on('console-message', (_event, level, message) => {
    if (level >= 2) console.error('Renderer error:', message.slice(0, 500));
  });
  menuManager.createTray();

  window.on("close", (event) => {
    if (!isQuitting) {
      event.preventDefault();
      window.hide();
    }
    return false;
  });

  // if (process.env.NODE_ENV === "development") {
  //   globalShortcut.register("F12", () => {
  //     const window = windowManager.getWindow();
  //     if (!window) return;

  //     if (window.webContents.isDevToolsOpened()) {
  //       window.webContents.closeDevTools();
  //     } else {
  //       window.webContents.openDevTools();
  //     }
  //   });
  // }

  setupIPC();
  setTimeout(recordDesktopState, 3000);
  ipcMain.on('mode-change-rendered', () => setTimeout(recordDesktopState, 100));
  if (process.env.ASSISTANT_OPEN_TEST_SCREEN === '1') openTestScreen().catch(error => console.error('Test screen:', error.message));

  app.on("activate", () => {
    const window = windowManager.getWindow();
    if (window) {
      window.show();
    }
  });

  app.on("browser-window-created", (_, window) => {
    optimizer.watchWindowShortcuts(window);
  });

  app.on('web-contents-created', (_, contents) => {
    contents.session.setPermissionRequestHandler((webContents, permission, callback) => {
      if (permission === 'media') {
        callback(true);
      } else {
        callback(false);
      }
    });
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("before-quit", () => {
  isQuitting = true;
  menuManager.destroy();
  globalShortcut.unregisterAll();
});
