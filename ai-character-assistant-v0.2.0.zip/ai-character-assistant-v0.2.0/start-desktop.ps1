﻿param([switch]$TestMicrophone, [switch]$TestScreen)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
New-Item -ItemType Directory -Path '.runtime' -Force | Out-Null
$env:ASSISTANT_PROJECT_ROOT = $PSScriptRoot
$env:ASSISTANT_OPEN_TEST_SCREEN = if ($TestScreen) { '1' } else { '0' }
if ($TestMicrophone) { $env:ASSISTANT_FAKE_MIC = Join-Path $PSScriptRoot 'test-results\speech-mic-fixture.wav' }
else { Remove-Item Env:ASSISTANT_FAKE_MIC -ErrorAction SilentlyContinue }
$entry = Join-Path $PSScriptRoot 'frontend\out\main\index.js'
$exe = Join-Path $PSScriptRoot 'frontend\node_modules\electron\dist\electron.exe'
if (-not (Test-Path -LiteralPath $entry) -or -not (Test-Path -LiteralPath $exe)) { throw '먼저 데스크톱 빌드와 Electron 설치를 완료해주세요.' }
$desktop = Start-Process -FilePath $exe -ArgumentList ('"' + $entry + '"') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot '.runtime\desktop.log') -RedirectStandardError (Join-Path $PSScriptRoot '.runtime\desktop-error.log') -PassThru
Set-Content -LiteralPath '.runtime\desktop.pid' -Value $desktop.Id
Write-Output "Desktop PID: $($desktop.Id)"
